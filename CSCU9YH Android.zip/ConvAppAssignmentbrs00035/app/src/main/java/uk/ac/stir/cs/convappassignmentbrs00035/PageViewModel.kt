package uk.ac.stir.cs.convappassignmentbrs00035

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * View Model Class, stores the values from the page 1 fragment spinners
 */
class PageViewModel : ViewModel() {

     val unitMeasurement = MutableLiveData<Any>()
     val unitConvertTo = MutableLiveData<Any>()

    fun unitMeasurementCommunicator(unitM:String) {
        unitMeasurement.value = unitM
    }
    fun unitConvertToCommunicator(unitConvTo: String){
        unitConvertTo.value = unitConvTo
    }

}