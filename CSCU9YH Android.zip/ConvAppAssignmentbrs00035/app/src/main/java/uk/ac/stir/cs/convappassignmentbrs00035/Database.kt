package uk.ac.stir.cs.convappassignmentbrs00035

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

val DATABASE_NAME = "MyDB"
val TABLE_NAME = "Conversions"
val COL_ID = "ID"
val COL_Unit_Measurement = "Units"
val COL_Converion_To = "Conversion_To"
val COL_Conversion_Ratio = "Ratio"

/**
 * database class
 */
class Database (context: Context) : SQLiteOpenHelper(context,DATABASE_NAME,null,1) {
    override fun onCreate(db: SQLiteDatabase?) {

        val createTable = "CREATE TABLE " + TABLE_NAME +" (" +
                COL_ID +" INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_Unit_Measurement + " VARCHAR(256)," +
                COL_Converion_To +" VARCHAR(256)," +
                COL_Conversion_Ratio + " FLOAT)"
                ")"

        db?.execSQL(createTable)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("Not yet implemented")
    }

    /**
     * getRatio returns the ratio value based on SQL Query return results
     */
    fun getRatio(db: SQLiteDatabase, unitMeasurement: String, convertTo: String): Double {
        var ratio = 0.0
        val query =
            "SELECT $COL_Conversion_Ratio FROM $TABLE_NAME WHERE $COL_Unit_Measurement == '$unitMeasurement' AND $COL_Converion_To == '$convertTo';" //query will return the ratio value if a match is found
        val result = db.rawQuery(query,null)

        //if a match was was found
        if (result.moveToFirst()){
            ratio = result.getDouble(result.getColumnIndex(COL_Conversion_Ratio)) // return the ratio value from the ratio colum

        }

        return ratio
    }

    /**
     * populate the database
     */
    fun populateDatabase(){

        val db = this.writableDatabase
        var values = ContentValues()


        //currency
        values.put(COL_Unit_Measurement, "GBP £")
        values.put(COL_Converion_To, "Euros €")
        values.put(COL_Conversion_Ratio, "1.12")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Euros €")
        values.put(COL_Converion_To, "GBP £")
        values.put(COL_Conversion_Ratio, "0.90")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "GBP £")
        values.put(COL_Converion_To, "USD $")
        values.put(COL_Conversion_Ratio, "1.32")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "USD $")
        values.put(COL_Converion_To, "GBP £")
        values.put(COL_Conversion_Ratio, "0.76")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "USD $")
        values.put(COL_Converion_To, "Euros €")
        values.put(COL_Conversion_Ratio, "0.84")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Euros €")
        values.put(COL_Converion_To, "USD $")
        values.put(COL_Conversion_Ratio, "1.19")
        db.insert(TABLE_NAME, null, values)


        //distance
        values.put(COL_Unit_Measurement, "Miles")
        values.put(COL_Converion_To, "kilometers")
        values.put(COL_Conversion_Ratio, "1.609")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "kilometers")
        values.put(COL_Converion_To, "Miles")
        values.put(COL_Conversion_Ratio, "0.62")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Meters")
        values.put(COL_Converion_To, "Miles")
        values.put(COL_Conversion_Ratio, "0.0006")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Miles")
        values.put(COL_Converion_To, "Meters")
        values.put(COL_Conversion_Ratio, "1609.34")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "kilometers")
        values.put(COL_Converion_To, "Meters")
        values.put(COL_Conversion_Ratio, "1000")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Meters")
        values.put(COL_Converion_To, "kilometers")
        values.put(COL_Conversion_Ratio, "0.001")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "kilometers")
        values.put(COL_Converion_To, "Yards")
        values.put(COL_Conversion_Ratio, "1093.61")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Yards")
        values.put(COL_Converion_To, "kilometers")
        values.put(COL_Conversion_Ratio, "0.0009")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Yards")
        values.put(COL_Converion_To, "Miles")
        values.put(COL_Conversion_Ratio, "0.00057")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Miles")
        values.put(COL_Converion_To, "Yards")
        values.put(COL_Conversion_Ratio, "1760")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Meters")
        values.put(COL_Converion_To, "Yards")
        values.put(COL_Conversion_Ratio, "1.09361")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Yards")
        values.put(COL_Converion_To, "Meters")
        values.put(COL_Conversion_Ratio, "0.9144")
        db.insert(TABLE_NAME, null, values)

        //volume
        values.put(COL_Unit_Measurement, "Liters")
        values.put(COL_Converion_To, "Milliliters")
        values.put(COL_Conversion_Ratio, "1000")
        db.insert(TABLE_NAME, null, values)


        values.put(COL_Unit_Measurement, "Milliliters")
        values.put(COL_Converion_To, "Liters")
        values.put(COL_Conversion_Ratio, "0.001")
        db.insert(TABLE_NAME, null, values)


        values.put(COL_Unit_Measurement, "Liters")
        values.put(COL_Converion_To, "Pints")
        values.put(COL_Conversion_Ratio, "1.76")
        db.insert(TABLE_NAME, null, values)


        values.put(COL_Unit_Measurement, "Pints")
        values.put(COL_Converion_To, "Liters")
        values.put(COL_Conversion_Ratio, "0.568")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Liters")
        values.put(COL_Converion_To, "Gallons")
        values.put(COL_Conversion_Ratio, "0.264172")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Gallons")
        values.put(COL_Converion_To, "Liters")
        values.put(COL_Conversion_Ratio, "4.54609")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Gallons")
        values.put(COL_Converion_To, "Pints")
        values.put(COL_Conversion_Ratio, "6.66139")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Pints")
        values.put(COL_Converion_To, "Gallons")
        values.put(COL_Conversion_Ratio, "0.150")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Pints")
        values.put(COL_Converion_To, "Milliliters")
        values.put(COL_Conversion_Ratio, "568.261")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Milliliters")
        values.put(COL_Converion_To, "Pints")
        values.put(COL_Conversion_Ratio, "0.00175975")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Milliliters")
        values.put(COL_Converion_To, "Gallons")
        values.put(COL_Conversion_Ratio, "0.000264172")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Gallons")
        values.put(COL_Converion_To, "Milliliters")
        values.put(COL_Conversion_Ratio, "3785.41")
        db.insert(TABLE_NAME, null, values)


       //weight

        values.put(COL_Unit_Measurement, "Kilograms")
        values.put(COL_Converion_To, "Pounds")
        values.put(COL_Conversion_Ratio, "2.205")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Pounds")
        values.put(COL_Converion_To, "Kilograms")
        values.put(COL_Conversion_Ratio, "0.453592")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Kilograms")
        values.put(COL_Converion_To, "Grams")
        values.put(COL_Conversion_Ratio, "1000")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Grams")
        values.put(COL_Converion_To, "Kilograms")
        values.put(COL_Conversion_Ratio, "0.001")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Kilograms")
        values.put(COL_Converion_To, "Stone")
        values.put(COL_Conversion_Ratio, "0.157")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Stone")
        values.put(COL_Converion_To, "Kilograms")
        values.put(COL_Conversion_Ratio, "6.35029")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Pounds")
        values.put(COL_Converion_To, "Grams")
        values.put(COL_Conversion_Ratio, "453.592")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Grams")
        values.put(COL_Converion_To, "Pounds")
        values.put(COL_Conversion_Ratio, "0.0022")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Pounds")
        values.put(COL_Converion_To, "Stone")
        values.put(COL_Conversion_Ratio, "0.0714")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Stone")
        values.put(COL_Converion_To, "Pounds")
        values.put(COL_Conversion_Ratio, "14")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Stone")
        values.put(COL_Converion_To, "Grams")
        values.put(COL_Conversion_Ratio, "6350.29")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Grams")
        values.put(COL_Converion_To, "Stone")
        values.put(COL_Conversion_Ratio, "0.000157")
        db.insert(TABLE_NAME, null, values)

        //speed
        values.put(COL_Unit_Measurement, "Meters Per Second")
        values.put(COL_Converion_To, "Kilometers Per Hour")
        values.put(COL_Conversion_Ratio, "3.6")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Meters Per Second")
        values.put(COL_Converion_To, "Miles Per Hour")
        values.put(COL_Conversion_Ratio, "2.237")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Miles Per Hour")
        values.put(COL_Converion_To, "Kilometers Per Hour")
        values.put(COL_Conversion_Ratio, "1.609")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Miles Per Hour")
        values.put(COL_Converion_To, "Meters Per Second")
        values.put(COL_Conversion_Ratio, "2.237")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Kilometers Per Hour")
        values.put(COL_Converion_To, "Miles Per Hour")
        values.put(COL_Conversion_Ratio, "1.609")
        db.insert(TABLE_NAME, null, values)

        values.put(COL_Unit_Measurement, "Kilometers Per Hour")
        values.put(COL_Converion_To, "Meters Per Second")
        values.put(COL_Conversion_Ratio, "3.6")
        db.insert(TABLE_NAME, null, values)
    }


}