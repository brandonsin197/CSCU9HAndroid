package uk.ac.stir.cs.convappassignmentbrs00035

import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.page1_fragment.*

/**
 * page1Fragment responsible for spinner selection of units
 */
class Page1Fragment : Fragment() {

    private var model: PageViewModel?= null //view model to allow fragments to communicate
    private var list = ArrayList<String>()
    private var unitMeasurementVal = ""
    private var convertToVal = ""
    var spinnerArray: ArrayAdapter<String>? =  null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view =inflater.inflate(R.layout.page1_fragment,container,false)

        return  view
    }

    /***
     * onActivityCreated tells the fragment when it has ran it's own onCreate
     */
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        if (savedInstanceState != null) {

            //gets and sets the spinners positions that was saved in the savedInstanceState
            unitSpinner.setSelection(savedInstanceState.getInt("unitSpinner"))
            unitMeasurement.setSelection(savedInstanceState.getInt("unitMeasurementSpinner"))
            convertToSpinner.setSelection(savedInstanceState.getInt("unitConversionSpinner"))

        }
    }

    /***
     * setUnitsCommunication responsible for communicating with the pageViewModel
     */
    fun setUnitsCommunication(spinner: String){

        val page2Fragment = Page2Fragment() // creates an instance of page2Fragment
        val fragmentTransaction = fragmentManager!!.beginTransaction()

        if(list.isNotEmpty()) {

                //if unitMeasurment spinner has been changed send the unitMeasurementVal to the pageViewModel
            if (spinner == "UnitMeasurement") {
                model!!.unitMeasurementCommunicator(
                    unitMeasurementVal
                )
                fragmentTransaction.replace(R.id.unitValueReceiver, page2Fragment)
            }else
            if (spinner == "ConvertTo") {
                model!!.unitConvertToCommunicator(
                    convertToVal
                )
                fragmentTransaction.replace(R.id.convertToReceiver, page2Fragment)
            }

        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        model = ViewModelProviders.of(activity!!).get(PageViewModel::class.java) //view model

        //set up spinners
        val unitSpinner = view.findViewById(R.id.unitSpinner) as Spinner
        val unitMeasurement = view.findViewById(R.id.unitMeasurement) as Spinner
        val convertToSpinner = view.findViewById(R.id.convertToSpinner) as Spinner

        //spinner arrayAdapter using default spinner layout and setting content to list
         val spinnerArray  = ArrayAdapter(
            context,
            android.R.layout.simple_spinner_item,
            list
        )
        spinnerArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        //setting spinners arrayAdapter, this will allow the automatic change in the spinner selection values
        unitMeasurement.adapter = spinnerArray
        convertToSpinner.adapter = spinnerArray

        //spinners listeners
        convertToSpinner.onItemSelectedListener= object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                //returns the value at the current position, the position will change each time a new item is selected
                convertToVal  = parent.getItemAtPosition(position).toString()
                setUnitsCommunication("ConvertTo")
                spinnerArray.notifyDataSetChanged()
            }}

        unitMeasurement.onItemSelectedListener= object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {


                unitMeasurementVal = parent.getItemAtPosition(position).toString()
                setUnitsCommunication("UnitMeasurement")
                spinnerArray.notifyDataSetChanged()



            }}


            unitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                //loads the respected string array based on unitSelection spinners position
               if (position == 0){
                   list.clear()
                   list.addAll(resources.getStringArray(R.array.Currency))

               }
                if (position == 1) {
                    list.clear()
                    list.addAll(resources.getStringArray(R.array.Weight))

                }
                if(position == 2){
                    list.clear()
                    list.addAll(resources.getStringArray(R.array.Volume))

                }
                if(position == 3){
                    list.clear()
                    list.addAll(resources.getStringArray(R.array.Distance))

                }
                if(position == 4){
                    list.clear()
                    list.addAll(resources.getStringArray(R.array.Speed))
                }
                defaultUnitValues()
                spinnerArray.notifyDataSetChanged()
            }

            fun defaultUnitValues(){
                //setting the spinners default position when unit selection is changed
                unitMeasurement.setSelection(0)
                convertToSpinner.setSelection(0)
                unitMeasurementVal = list[0]
                convertToVal = list[0]
                setUnitsCommunication("UnitMeasurement")
                setUnitsCommunication("ConvertTo")
            }
            }
    }

    //savedState saves values when a new fragment is created
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("unitSpinner", unitSpinner.selectedItemPosition)
        outState.putInt("unitMeasurementSpinner", unitMeasurement.selectedItemPosition)
        outState.putInt("unitConversionSpinner", convertToSpinner.selectedItemPosition)
        outState.putStringArrayList("list", list)


    }

}




















