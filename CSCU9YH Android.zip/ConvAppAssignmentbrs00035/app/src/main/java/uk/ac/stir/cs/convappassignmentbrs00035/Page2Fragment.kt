package uk.ac.stir.cs.convappassignmentbrs00035

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.page2_fragment.*
import java.lang.Exception
import java.text.DecimalFormat

class Page2Fragment : Fragment() {


    var unitMesVal = ""
    var unitConvVal = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.page2_fragment, container, false)
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //create instance of database and populate
        val db = Database(context!!)
        db.populateDatabase()

        //view model
        val model = ViewModelProviders.of(activity!!).get(PageViewModel::class.java)

        //getting unit values from view model
        model.unitMeasurement.observe(this, object: Observer<Any>{
            override fun onChanged(o: Any?) {
               unitValueReceiver.text = o!!.toString()
                unitMesVal = o!!.toString() //set the unitMesVal to value from view model if changed
            }
        })

        model.unitConvertTo.observe(this, object: Observer<Any>{
            override fun onChanged(o: Any?) {
                convertToReceiver.text = o!!.toString()
                unitConvVal = o!!.toString()
            }
        })



        //setting calculator values
        val input = view.findViewById(R.id.calInputVal) as EditText
        val result = view.findViewById(R.id.calResult) as EditText
        val clearButton = view.findViewById(R.id.calcButtonC) as Button
        val calcButton0 = view.findViewById(R.id.calcButton0) as Button
        val calcButton1 = view.findViewById(R.id.calcButton1) as Button
        val calcButton2 = view.findViewById(R.id.calcButton2) as Button
        val calcButton3 = view.findViewById(R.id.calcButton3) as Button
        val calcButton4 = view.findViewById(R.id.calcButton4) as Button
        val calcButton5 = view.findViewById(R.id.calcButton5) as Button
        val calcButton6 = view.findViewById(R.id.calcButton6) as Button
        val calcButton7 = view.findViewById(R.id.calcButton7) as Button
        val calcButton8 = view.findViewById(R.id.calcButton8) as Button
        val calcButton9 = view.findViewById(R.id.calcButton9) as Button
        val calcEquals = view.findViewById(R.id.calcButtonEquals) as Button
        val calcDot = view.findViewById(R.id.dotButton) as Button

        //input val
        fun setInputValue(value: String){
            //adds each value to the string
            input.setText(StringBuilder().append(input.text.toString()).append(value))
        }
        fun clearInputValue(){
            input.text = null
            result.text = null

        }

        //handles conversion ratio
        fun convertUnits(){
            var ratio: Double = 0.0

            val df = DecimalFormat("#,###.#######")
                //if unit measurement val and the unit it's converting to are the same the ratio is 1
            if(unitMesVal == unitConvVal){
                ratio = 1.0
            }else
            //return the ratio value from the database
            ratio  = db.getRatio(db.readableDatabase,  unitMesVal, unitConvVal)

            try{
                //if needing to divide when converting kilometers Per Hour
                if(unitMesVal == "Kilometers Per Hour"){

                    //calculate the result value
                    result.setText(java.lang.StringBuilder().append(" ").append("$unitConvVal ").append(df.format((input.text.toString().toDouble() / ratio ))))

                }else
                    //if need to divide if converting Miles Per hour to Meters Per second
                    if (unitMesVal == "Miles Per Hour" && unitConvVal == "Meters Per Second"){

                        //calculate the result value
                        result.setText(java.lang.StringBuilder().append(" ").append("$unitConvVal ").append(df.format((input.text.toString().toDouble() / ratio))))

                    }else

                //calculate the result value
                result.setText(java.lang.StringBuilder().append(" ").append("$unitConvVal ").append(df.format(ratio.times(input.text.toString().toDouble()))))

            }catch (e: Exception){
                //error caught and error message displayed
                Toast.makeText(context,
                    "Incorrect Numeric Value",
                    Toast.LENGTH_LONG).show()
            }//end catch
        }

        //calculate listeners
        clearButton.setOnClickListener {
            clearInputValue()
        }
        calcButton0.setOnClickListener {
            setInputValue("0")
        }
        calcButton1.setOnClickListener {
            setInputValue("1")
        }
        calcButton2.setOnClickListener {
            setInputValue("2")
        }
        calcButton3.setOnClickListener {
            setInputValue("3")
        }
        calcButton4.setOnClickListener {
            setInputValue("4")
        }
        calcButton5.setOnClickListener {
            setInputValue("5")
        }
        calcButton6.setOnClickListener {
            setInputValue("6")
        }
        calcButton7.setOnClickListener {
            setInputValue("7")
        }
        calcButton8.setOnClickListener {
            setInputValue("8")
        }
        calcButton9.setOnClickListener {
            setInputValue("9")
        }
        calcEquals.setOnClickListener {
            convertUnits()
        }

        calcDot.setOnClickListener(){
            setInputValue(".")
        }



    }
}

